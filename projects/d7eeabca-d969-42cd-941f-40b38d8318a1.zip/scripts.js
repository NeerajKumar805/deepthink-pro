// Add any JavaScript functionality here
console.log("Portfolio loaded!");