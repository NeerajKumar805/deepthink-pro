$(document).ready(function() {
    // Add any custom JavaScript here
    console.log("Page loaded!");
});