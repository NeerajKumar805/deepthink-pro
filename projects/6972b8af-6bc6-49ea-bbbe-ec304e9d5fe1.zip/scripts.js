$(document).ready(function() {
    // Add any JavaScript functionality here
    console.log("Page loaded!");
});